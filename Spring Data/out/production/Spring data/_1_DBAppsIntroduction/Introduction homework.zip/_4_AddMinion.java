package _1_DBAppsIntroduction;

import java.sql.Connection;
import java.sql.SQLException;

public class _4_AddMinion {
    public static void main(String[] args) throws SQLException {
        Connection connection = Utils.getSQLConnection();


    }

}
